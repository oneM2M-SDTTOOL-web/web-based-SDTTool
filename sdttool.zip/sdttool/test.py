# from SDTTool_translate import *
from SDTTool_translate import SDTTool
# sdt.main(infile='media/Uploaded Files/Echo.xml', outfile='media/Uploaded Files/Echo_out.md')
SDTTool.main(infile='C:/Users/incla/Desktop/origin/SDT-TOOL-web-based-main (1)/1204_uploadsave/Echo.xml',
             outfile='C:/Users/incla/Desktop/origin/SDT-TOOL-web-based-main (1)/1204_uploadsave/Echo.md')
